const t={__name:"InstructionPermission",props:["isCollapse"],setup(s){return(n,r)=>"InstructionPermission"}};export{t as default};
