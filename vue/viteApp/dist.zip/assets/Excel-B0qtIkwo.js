import{_ as c}from"./index-DgwAC2JF.js";const e={};function r(n,t){return null}const o=c(e,[["render",r]]);export{o as default};
