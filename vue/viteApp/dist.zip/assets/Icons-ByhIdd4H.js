import{_ as c}from"./index-DgwAC2JF.js";const n={};function r(e,t){return null}const o=c(n,[["render",r]]);export{o as default};
