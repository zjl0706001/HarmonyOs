import{_ as r}from"./index-DgwAC2JF.js";const c={};function e(n,t){return null}const o=r(c,[["render",e]]);export{o as default};
