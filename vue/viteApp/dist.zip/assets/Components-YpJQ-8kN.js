import{_ as n}from"./index-DgwAC2JF.js";const e={};function r(t,c){return null}const _=n(e,[["render",r]]);export{_ as default};
