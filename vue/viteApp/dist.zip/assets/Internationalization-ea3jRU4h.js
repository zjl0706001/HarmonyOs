import{_ as n}from"./index-DgwAC2JF.js";const t={};function r(e,c){return null}const _=n(t,[["render",r]]);export{_ as default};
