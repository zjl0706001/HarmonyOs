import{_ as e}from"./index-DgwAC2JF.js";const t={};function n(r,c){return null}const o=e(t,[["render",n]]);export{o as default};
