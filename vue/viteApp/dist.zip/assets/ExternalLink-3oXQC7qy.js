import{_ as n}from"./index-DgwAC2JF.js";const r={};function e(t,c){return null}const o=n(r,[["render",e]]);export{o as default};
