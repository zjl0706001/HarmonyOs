import{_ as r}from"./index-DgwAC2JF.js";const c={};function e(n,o){return null}const _=r(c,[["render",e]]);export{_ as default};
