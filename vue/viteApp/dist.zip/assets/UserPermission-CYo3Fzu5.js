import{g as E,a as I,r as k,b as $,t as C}from"./user-rFJSX1XW.js";import{r as T,i as c,b as U,n as z,d as m,e as o,w as i,f as b,F as M,a0 as _,a1 as d}from"./index-DgwAC2JF.js";import"./axios-upsvKRUO.js";const N={style:{display:"flex"}},S={__name:"UserPermission",setup(V){const p=T([]);E().then(n=>{p.value=n.data});const f=n=>{I(n).then(e=>{alert(e.data.message)}),p.value=p.value.filter(e=>e.username!==n)},w=()=>{_.confirm(`
    <div style="font-size: 14px; color: #333;">
      <div style="margin-bottom: 15px;">
        <label for="username" style="font-weight: bold;">用户名：</label>
        <input id="username" type="text" class="el-input__inner" placeholder="请输入用户名" style="width: 100%; padding: 8px; border-radius: 5px; border: 1px solid #ccc;">
      </div>
      <div style="margin-bottom: 15px;">
        <label for="password" style="font-weight: bold;">密码：</label>
        <input id="password" type="password" class="el-input__inner" placeholder="请输入密码" style="width: 100%; padding: 8px; border-radius: 5px; border: 1px solid #ccc;">
      </div>
      <div style="margin-bottom: 15px;">
        <label for="email" style="font-weight: bold;">电子邮件：</label>
        <input id="email" type="text" class="el-input__inner" placeholder="请输入电子邮件" style="width: 100%; padding: 8px; border-radius: 5px; border: 1px solid #ccc;">
      </div>
      <div style="margin-bottom: 15px;">
        <label for="phone_number" style="font-weight: bold;">电话：</label>
        <input id="phone_number" type="text" class="el-input__inner" placeholder="请输入电话" style="width: 100%; padding: 8px; border-radius: 5px; border: 1px solid #ccc;">
      </div>
      <div style="margin-bottom: 15px;">
        <label for="sex" style="font-weight: bold;">性别：</label>
        <input id="sex" type="text" class="el-input__inner" placeholder="请输入性别" style="width: 100%; padding: 8px; border-radius: 5px; border: 1px solid #ccc;">
      </div>
      <div style="margin-bottom: 15px;">
        <label for="age" style="font-weight: bold;">年龄：</label>
        <input id="age" type="text" class="el-input__inner" placeholder="请输入年龄" style="width: 100%; padding: 8px; border-radius: 5px; border: 1px solid #ccc;">
      </div>
    </div>
    `,"添加用户",{confirmButtonText:"确定",cancelButtonText:"取消",showCancelButton:!0,dangerouslyUseHTMLString:!0}).then(()=>{const n=document.getElementById("username").value,e=document.getElementById("password").value,a=document.getElementById("email").value,t=document.getElementById("phone_number").value,s=document.getElementById("sex").value,l=document.getElementById("age").value;if(!n||!e||!a||!t||!s||!l){d({type:"error",message:"请填写所有字段！"});return}k({username:n,password:e,email:a,phone_number:t,sex:s,age:l}).then(r=>{location.reload()}),d({type:"success",message:`用户添加成功！用户名：${n}`})}).catch(()=>{d({type:"info",message:"已取消添加用户"})})},B=(n,e,a,t,s,l)=>{_.confirm(`
    <div style="font-size: 14px; color: #333;">
      <div style="margin-bottom: 15px;">
        <label for="username" style="font-weight: bold;">用户名：</label>
        <input id="username" type="text" class="el-input__inner" value="${n}" disabled style="width: 100%; padding: 8px; border-radius: 5px; border: 1px solid #ccc;">
      </div>
      <div style="margin-bottom: 15px;">
        <label for="email" style="font-weight: bold;">电子邮件：</label>
        <input id="email" type="text" class="el-input__inner" value="${e}" placeholder="请输入电子邮件" style="width: 100%; padding: 8px; border-radius: 5px; border: 1px solid #ccc;">
      </div>
      <div style="margin-bottom: 15px;">
        <label for="phone_number" style="font-weight: bold;">电话：</label>
        <input id="phone_number" type="text" class="el-input__inner" value="${a}" placeholder="请输入电话" style="width: 100%; padding: 8px; border-radius: 5px; border: 1px solid #ccc;">
      </div>
      <div style="margin-bottom: 15px;">
        <label for="sex" style="font-weight: bold;">性别：</label>
        <input id="sex" type="text" class="el-input__inner" value="${t}" placeholder="请输入性别" style="width: 100%; padding: 8px; border-radius: 5px; border: 1px solid #ccc;">
      </div>
      <div style="margin-bottom: 15px;">
        <label for="age" style="font-weight: bold;">年龄：</label>
        <input id="age" type="text" class="el-input__inner" value="${s}" placeholder="请输入年龄" style="width: 100%; padding: 8px; border-radius: 5px; border: 1px solid #ccc;">
      </div>
      <div style="margin-bottom: 15px;display: flex">
        <label for="role" style="font-weight: bold;">admin：</label>
       <input id="role" type="checkbox" ${l==="admin"?"checked":""}>
      </div>
    </div>
    `,"修改用户信息",{confirmButtonText:"确定",cancelButtonText:"取消",showCancelButton:!0,dangerouslyUseHTMLString:!0}).then(()=>{const r=document.getElementById("username").value,g=document.getElementById("email").value,x=document.getElementById("phone_number").value,y=document.getElementById("sex").value,h=document.getElementById("age").value,v=document.getElementById("role").checked?"admin":"user";if(!r||!g||!x||!y||!h||!v){d({type:"error",message:"请填写所有字段！"});return}$({username:r,email:g,phone_number:x,sex:y,age:h}).then(u=>{console.log(u)}),C({username:r,role:v}).then(u=>{console.log(u),location.reload()}),d({type:"success",message:`修改用户信息成功！用户名：${r}`})}).catch(()=>{d({type:"info",message:"已取消修改"})})};return(n,e)=>{const a=c("el-button"),t=c("el-table-column"),s=c("el-table");return U(),z(M,null,[m("div",null,[o(a,{type:"primary",style:{margin:"20px"},plain:"",onClick:w},{default:i(()=>e[0]||(e[0]=[b(" 添加用户 ")])),_:1})]),m("div",null,[o(s,{size:"large",data:p.value,style:{width:"100%"}},{default:i(()=>[o(t,{prop:"id",label:"ID",width:"180"}),o(t,{prop:"username",label:"用户名"}),o(t,{prop:"phone_number",label:"手机号"}),o(t,{prop:"email",label:"邮箱"}),o(t,{prop:"sex",label:"性别"}),o(t,{prop:"age",label:"年龄"}),o(t,{prop:"role",label:"权限"}),o(t,{label:"操作"},{default:i(l=>[m("div",N,[o(a,{onClick:r=>B(l.row.username,l.row.email,l.row.phone_number,l.row.sex,l.row.age,l.row.role),type:"primary",size:"small"},{default:i(()=>e[1]||(e[1]=[b(" 修改 ")])),_:2},1032,["onClick"]),o(a,{onClick:r=>f(l.row.username),type:"danger",size:"small"},{default:i(()=>e[2]||(e[2]=[b(" 删除 ")])),_:2},1032,["onClick"])])]),_:1})]),_:1},8,["data"])])],64)}}};export{S as default};
