import{_ as e}from"./index-DgwAC2JF.js";const n={};function r(c,t){return null}const o=e(n,[["render",r]]);export{o as default};
