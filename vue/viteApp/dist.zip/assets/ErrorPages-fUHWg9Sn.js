import{_ as r}from"./index-DgwAC2JF.js";const e={};function c(n,t){return null}const o=r(e,[["render",c]]);export{o as default};
