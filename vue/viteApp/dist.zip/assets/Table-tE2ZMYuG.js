import{_ as e}from"./index-DgwAC2JF.js";const r={};function c(n,t){return null}const o=e(r,[["render",c]]);export{o as default};
